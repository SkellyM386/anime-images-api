# Anime Images API

<p>
A Wrapper for the Anime image API
</p>
<hr/>
